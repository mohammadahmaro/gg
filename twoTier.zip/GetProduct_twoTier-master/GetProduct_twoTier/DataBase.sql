﻿Create Database GetPro
Go

Use GetPro
Go

Create Table Gproducts
(
	ProductID int PRIMARY KEY IDENTITY(1,1),
	ProductName nvarchar(50),
	Design nvarchar(50),
	Color nvarchar(50),
)
Go